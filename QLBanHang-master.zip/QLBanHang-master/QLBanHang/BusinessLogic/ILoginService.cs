﻿namespace BusinessLogic
{
    public interface ILoginService
    {
        int Login(string userId, string password);
    }
}