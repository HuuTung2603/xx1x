﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    public partial class FormPhieuNhap : Form
    {
        string cs = "Data Source=huutung\\SQLEXPRESS;Initial Catalog=QLTH;Integrated Security=True;TrustServerCertificate=True";

        public FormPhieuNhap()
        {
            InitializeComponent();
            Load += (s, e) => LoadData();
        }
        void LoadData()
        {
            using (SqlDataAdapter da =
                new SqlDataAdapter("SELECT MaPhieuNhap,NhaCungCap,NgayNhap FROM PhieuNhap", cs))
            {
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvPhieuNhap.DataSource = dt;
            }
            dgvPhieuNhap.ReadOnly = true;
            dgvPhieuNhap.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            txtMaPhieuNhap.Enabled = true;
            txtMaPhieuNhap.ReadOnly = true;
            txtMaPhieuNhap.Clear();
            txtNhaCungCap.Clear();
            dtpNgayNhap.Value = DateTime.Today;
        }

        void Exec(string sql)
        {
            using (SqlConnection conn = new SqlConnection(cs))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@Ma", txtMaPhieuNhap.Text);
                cmd.Parameters.AddWithValue("@NCC", txtNhaCungCap.Text);
                cmd.Parameters.AddWithValue("@Ngay", dtpNgayNhap.Value);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            LoadData();
        }
        private void btnThem_Click(object s, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(cs))
            using (SqlCommand cmd = new SqlCommand(
                "INSERT INTO PhieuNhap(NhaCungCap,NgayNhap) VALUES(@NCC,@Ngay)", conn))
            {
                cmd.Parameters.AddWithValue("@NCC", txtNhaCungCap.Text);
                cmd.Parameters.AddWithValue("@Ngay", dtpNgayNhap.Value);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            LoadData();
        }

        private void btnSua_Click(object s, EventArgs e)
            => Exec("UPDATE PhieuNhap SET NhaCungCap=@NCC, NgayNhap=@Ngay WHERE MaPhieuNhap=@Ma");

        private void btnXoa_Click(object s, EventArgs e)
            => Exec("DELETE FROM PhieuNhap WHERE MaPhieuNhap=@Ma");

        private void dgvPhieuNhap_SelectionChanged(object s, EventArgs e)
        {
            if (dgvPhieuNhap.CurrentRow == null) return;
            txtMaPhieuNhap.Text = dgvPhieuNhap.CurrentRow.Cells[0].Value.ToString();
            txtNhaCungCap.Text = dgvPhieuNhap.CurrentRow.Cells[1].Value.ToString();
            dtpNgayNhap.Value = Convert.ToDateTime(dgvPhieuNhap.CurrentRow.Cells[2].Value);
            txtMaPhieuNhap.Enabled = false;
            dgvPhieuNhap.ReadOnly = true;
            dgvPhieuNhap.AllowUserToAddRows = false;
        }
        private void btnChiTiet_Click(object s, EventArgs e)
            => new FormChiTietPhieuNhap(txtMaPhieuNhap.Text).ShowDialog();
        private void btnDong_Click(object s, EventArgs e) => Close();
    }
}
