﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyNhapVaBanHangTapHoa
{
    public partial class FormChiTietPhieuNhap : Form
    {
        string cs = "Data Source=huutung\\SQLEXPRESS;Initial Catalog=QLTH;Integrated Security=True;TrustServerCertificate=True";
        string _maPhieuNhap;
        DataTable dt;

        public FormChiTietPhieuNhap(string maPhieuNhap)
        {
            InitializeComponent();
            _maPhieuNhap = maPhieuNhap;
            Load += Form_Load;
        }
        void Form_Load(object sender, EventArgs e)
        {
            // Đơn vị tiền
            cboDonViTien.Items.Add("VNĐ");
            cboDonViTien.SelectedIndex = 0;
            cboDonViTien.DropDownStyle = ComboBoxStyle.DropDownList;
            LoadCombo();
            cboMaPhieuNhap.SelectedValue = _maPhieuNhap;
            cboMaPhieuNhap.Enabled = false; // KHÓA MÃ PHIẾU NHẬP
            LoadData();
            ClearInput();
        }
        void LoadCombo()
        {
            using (SqlConnection c = new SqlConnection(cs))
            {
                DataTable pn = new DataTable();
                new SqlDataAdapter("SELECT MaPhieuNhap FROM PhieuNhap", c).Fill(pn);
                cboMaPhieuNhap.DataSource = pn;
                cboMaPhieuNhap.DisplayMember = "MaPhieuNhap";
                cboMaPhieuNhap.ValueMember = "MaPhieuNhap";

                DataTable sp = new DataTable();
                new SqlDataAdapter("SELECT MaSanPham, TenSanPham FROM SanPham", c).Fill(sp);
                sp.Columns.Add("HienThi", typeof(string), "MaSanPham + ' - ' + TenSanPham");
                cboMaSanPham.DataSource = sp;
                cboMaSanPham.DisplayMember = "HienThi";
                cboMaSanPham.ValueMember = "MaSanPham";
            }
        }

        void LoadData()
        {
            using (SqlDataAdapter da = new SqlDataAdapter(
                "SELECT * FROM ChiTietPhieuNhap WHERE MaPhieuNhap=@MaPN", cs))
            {
                da.SelectCommand.Parameters.AddWithValue("@MaPN", _maPhieuNhap);
                dt = new DataTable();
                da.Fill(dt);
                dgvChiTiet.DataSource = dt;
            }
            dgvChiTiet.ReadOnly = true;
            dgvChiTiet.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
        void ClearInput()
        {
            txtMaChiTiet.Clear();
            txtSoLuong.Text = "0";
            txtDonGia.Text = "0";
            txtThanhTien.Text = "0";
            txtThanhTien.ReadOnly = true;
            txtMaChiTiet.Enabled = true;
        }
        void TinhTien()
        {
            int sl = int.TryParse(txtSoLuong.Text, out int s) ? s : 0;
            decimal dg = decimal.TryParse(txtDonGia.Text.Replace(",", ""), out decimal d) ? d : 0;
            txtThanhTien.Text = (sl * dg).ToString("N0");
        }

        private void txtSoLuong_TextChanged(object s, EventArgs e) => TinhTien();
        private void txtDonGia_TextChanged(object s, EventArgs e) => TinhTien();
        void Exec(string sql)
        {
            using (SqlConnection c = new SqlConnection(cs))
            using (SqlCommand cmd = new SqlCommand(sql, c))
            {
                cmd.Parameters.AddWithValue("@MaCT", txtMaChiTiet.Text);
                cmd.Parameters.AddWithValue("@MaPN", _maPhieuNhap);
                cmd.Parameters.AddWithValue("@MaSP", cboMaSanPham.SelectedValue);
                cmd.Parameters.AddWithValue("@SL", int.Parse(txtSoLuong.Text));
                cmd.Parameters.AddWithValue("@DG", decimal.Parse(txtDonGia.Text.Replace(",", "")));
                cmd.Parameters.AddWithValue("@TT", decimal.Parse(txtThanhTien.Text.Replace(",", "")));

                c.Open();
                cmd.ExecuteNonQuery();
            }

            UpdateTongTien();
            LoadData();
            ClearInput();
        }

        void UpdateTongTien()
        {
            using (SqlConnection c = new SqlConnection(cs))
            using (SqlCommand cmd = new SqlCommand(
                @"UPDATE PhieuNhap
                  SET TongTien = (
                      SELECT ISNULL(SUM(SoLuong * DonGia),0)
                      FROM ChiTietPhieuNhap
                      WHERE MaPhieuNhap=@Ma
                  )
                  WHERE MaPhieuNhap=@Ma", c))
            {
                cmd.Parameters.AddWithValue("@Ma", _maPhieuNhap);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }
        private void btnThem_Click(object s, EventArgs e) =>
            Exec("INSERT INTO ChiTietPhieuNhap VALUES(@MaCT,@MaPN,@MaSP,@SL,@DG,@TT)");

        private void btnSua_Click(object s, EventArgs e) =>
            Exec(@"UPDATE ChiTietPhieuNhap
                   SET MaSanPham=@MaSP, SoLuong=@SL, DonGia=@DG, ThanhTien=@TT
                   WHERE MaChiTietPhieuNhap=@MaCT");

        private void btnXoa_Click(object s, EventArgs e) =>
            Exec("DELETE FROM ChiTietPhieuNhap WHERE MaChiTietPhieuNhap=@MaCT");

        private void dgvChiTiet_SelectionChanged(object s, EventArgs e)
        {
            if (dgvChiTiet.CurrentRow == null) return;
            var r = dgvChiTiet.CurrentRow;
            txtMaChiTiet.Text = r.Cells["MaChiTietPhieuNhap"].Value.ToString();
            cboMaSanPham.SelectedValue = r.Cells["MaSanPham"].Value;
            txtSoLuong.Text = r.Cells["SoLuong"].Value.ToString();
            txtDonGia.Text = r.Cells["DonGia"].Value.ToString();
            txtThanhTien.Text = r.Cells["ThanhTien"].Value.ToString();
            txtMaChiTiet.Enabled = false;
        }
        private void btnDong_Click(object s, EventArgs e) => Close();
    }
}
